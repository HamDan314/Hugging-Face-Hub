# Dataset: SST-2

## Origen
El proyecto utiliza el dataset SST-2, disponible desde Hugging Face Datasets mediante:

```python
from datasets import load_dataset
dataset = load_dataset("nyu-mll/glue", "sst2")
```

SST-2 es un conjunto de datos de clasificación binaria de sentimientos. Se usa para evaluar modelos de Procesamiento de Lenguaje Natural en textos cortos.

## Estructura

| Campo | Tipo | Descripción |
|---|---|---|
| sentence | Texto | Frase o reseña corta que será clasificada por sentimiento. |
| label | Entero | Etiqueta real del sentimiento: 0 = negativo, 1 = positivo. |
| idx | Entero | Identificador del registro dentro del dataset. |

## Uso en el prototipo
En el cuaderno se usa la partición `validation`, con una muestra de 300 registros seleccionados de forma reproducible con `shuffle(seed=42)`.
