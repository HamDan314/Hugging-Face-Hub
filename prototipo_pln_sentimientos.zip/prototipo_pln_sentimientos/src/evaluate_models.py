"""Evaluación reproducible de modelos Hugging Face para clasificación de sentimientos.

Ejecutar desde la raíz del repositorio:
    python src/evaluate_models.py
"""

import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from datasets import load_dataset
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from transformers import pipeline

MODELS = {
    "DistilBERT SST-2": "distilbert-base-uncased-finetuned-sst-2-english",
    "BERT SST-2": "textattack/bert-base-uncased-SST-2",
    "RoBERTa Sentiment": "siebert/sentiment-roberta-large-english",
}


def normalize_label(pred_label: str) -> int:
    label = str(pred_label).upper()
    if label in ["POSITIVE", "LABEL_1", "1", "POS"]:
        return 1
    if label in ["NEGATIVE", "LABEL_0", "0", "NEG"]:
        return 0
    return 1 if "POS" in label or label.endswith("_1") else 0


def evaluate_model(model_name: str, model_id: str, texts, y_true, device: int, batch_size: int = 16) -> dict:
    clf = pipeline(
        task="sentiment-analysis",
        model=model_id,
        tokenizer=model_id,
        device=device,
        truncation=True,
    )

    _ = clf(["This is a warm up example."])
    start = time.time()
    preds_raw = clf(list(texts), batch_size=batch_size)
    elapsed = time.time() - start

    y_pred = np.array([normalize_label(item["label"]) for item in preds_raw])

    return {
        "Modelo": model_name,
        "Model ID": model_id,
        "Accuracy": accuracy_score(y_true, y_pred),
        "Precision": precision_score(y_true, y_pred, zero_division=0),
        "Recall": recall_score(y_true, y_pred, zero_division=0),
        "F1-score": f1_score(y_true, y_pred, zero_division=0),
        "Latencia promedio (ms/texto)": (elapsed / len(texts)) * 1000,
        "Tiempo total inferencia (s)": elapsed,
    }


def main() -> None:
    dataset = load_dataset("nyu-mll/glue", "sst2")
    n_eval = 300
    eval_data = dataset["validation"].shuffle(seed=42).select(range(n_eval))

    texts = eval_data["sentence"]
    y_true = np.array(eval_data["label"])
    device = 0 if torch.cuda.is_available() else -1

    results = []
    for model_name, model_id in MODELS.items():
        print(f"Evaluando {model_name}...")
        results.append(evaluate_model(model_name, model_id, texts, y_true, device))

    results_df = pd.DataFrame(results)
    Path("results").mkdir(exist_ok=True)
    results_df.to_csv("results/resultados_modelos_pln.csv", index=False)
    print(results_df)
    print("Resultados guardados en results/resultados_modelos_pln.csv")


if __name__ == "__main__":
    main()
